package com.example.cleaner

import java.io.File
import java.security.MessageDigest

data class ScanResult(
    val junk: List<File> = emptyList(),
    val large: List<File> = emptyList(),
    val dupes: List<File> = emptyList(),
) {
    fun without(paths: Set<String>) = ScanResult(
        junk.filterNot { it.path in paths },
        large.filterNot { it.path in paths },
        dupes.filterNot { it.path in paths },
    )
}

fun File.sizeSafe(): Long = if (isDirectory) 0L else length()

object Scanner {
    private val junkExt = setOf("tmp", "log", "temp", "bak", "old", "chk", "dmp")
    private val junkDirs = setOf(
        "cache", ".cache", "thumbnails", ".thumbnails",
        ".trash", ".statuses", "lost+found",
    )
    private const val LARGE = 100L * 1024 * 1024   // 100 MB
    private const val DUPE_MIN = 1L * 1024 * 1024  // 1 MB

    fun scan(root: File): ScanResult {
        val junk = mutableListOf<File>()
        val large = mutableListOf<File>()
        val bySize = HashMap<Long, MutableList<File>>()

        // Android/data dan Android/obb disekat oleh sistem, lewati.
        // Android/media boleh dibaca (cth. WhatsApp), jadi diimbas.
        val blocked = setOf(File(root, "Android/data").path, File(root, "Android/obb").path)

        root.walkTopDown()
            .onEnter { it.path !in blocked }
            .forEach { f ->
                if (f == root) return@forEach

                if (f.isDirectory) {
                    // folder kosong (bukan folder paras atas seperti Download/DCIM)
                    if (f.parentFile != root && f.list()?.isEmpty() == true) junk += f
                    return@forEach
                }

                val len = f.length()
                val ext = f.extension.lowercase()
                val folders = f.path.removePrefix(root.path).split('/').dropLast(1)
                val inJunkDir = folders.any { it.lowercase() in junkDirs }

                val isJunk = len == 0L ||
                    ext in junkExt ||
                    inJunkDir ||
                    (ext == "apk" && f.parentFile?.name.equals("Download", true))

                if (isJunk) {
                    junk += f
                } else {
                    if (len >= LARGE) large += f
                    if (len >= DUPE_MIN) bySize.getOrPut(len) { mutableListOf() } += f
                }
            }

        val dupes = mutableListOf<File>()
        for (group in bySize.values) {
            if (group.size < 2) continue
            group.mapNotNull { f -> md5(f)?.let { it to f } }
                .groupBy({ it.first }, { it.second })
                .values
                .filter { it.size > 1 }
                .forEach { same ->
                    // simpan yang paling lama, sisanya dianggap duplikat
                    dupes += same.sortedBy { it.lastModified() }.drop(1)
                }
        }

        return ScanResult(
            junk = junk.sortedByDescending { it.sizeSafe() },
            large = large.sortedByDescending { it.length() },
            dupes = dupes.sortedByDescending { it.length() },
        )
    }

    private fun md5(f: File): String? = try {
        val md = MessageDigest.getInstance("MD5")
        f.inputStream().buffered().use { s ->
            val buf = ByteArray(64 * 1024)
            while (true) {
                val n = s.read(buf)
                if (n < 0) break
                md.update(buf, 0, n)
            }
        }
        md.digest().joinToString("") { "%02x".format(it) }
    } catch (e: Exception) {
        null
    }
}
